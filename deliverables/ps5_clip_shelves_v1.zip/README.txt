PS5 (original, disc) – clip shelves for a flat "box" side plate
================================================================
Derived from: "PS5 (Original - not slim) Side Panels" by Rhys34512 (Printables #973426),
licensed CC BY-NC 4.0. This remix inherits it: personal/non-commercial use, keep attribution.

Files
  shelf_flat_{bottom,left,right,middle}.stl   – flat (non-drive) side, 11 clips
  shelf_disk_{bottom,left,middle,right}.stl   – disc-drive side, 7 clips
Coordinates are the scan's own: every shelf is already in its correct position relative to
the others. Import all four of a side together and they line up.

Geometry
  - Console side of each shelf = scanned stock inner surface + original hooks.
  - Back of each shelf = one flat glue face, shared plane per side.
    Plane = stock plate's outermost point (so plate floor sits ~flush with stock width).
    Result: 2.5 mm tray floor -> ~109 mm total console width (devynPC reports 108 mm).
  - Shelf height varies 3–36 mm (flat side) / up to ~35 mm (disc side), following the flare.

Print
  - Orientation: as installed (hooks' lips pointing up). Layers then run along each hook
    shaft, the strong direction. Brim on the tall ones (flat left 196 mm, flat right 214 mm).
  - ASA or ABS (same as the tray, so you can solvent-weld). PETG works; avoid PLA.
  - 4+ walls, 100% infill within ~10 mm of each hook (modifier) – the hooks take the load.

Glue-in method (console as jig)
  1. Lay the console on its side, stock plate removed. Click all shelves onto their slots
     and slide them into the locked position.
  2. Glue on the shelves' flat faces (2K epoxy or ABS slurry; tape the console around them).
  3. Lower the tray onto the shelves, aligned by its rim; weight it, let it cure.
  4. Slide the finished plate down/off like a stock plate.
