PS5 (original, disc) - clip shelves v2 for a flat side plate
============================================================
Derived from "PS5 (Original - not slim) Side Panels" by Rhys34512 (Printables #973426),
licensed CC BY-NC 4.0. This remix inherits it: non-commercial use, keep attribution.

Print the two fit-test coupons first. This shelf set is unverified on a real console.

Files
  shelf_flat_{bottom,left,right,right_low,middle}.stl  - flat side, 11 hooks
  shelf_disk_{bottom,left,middle,right}.stl            - disc side, 7 hooks
Coordinates are the scan's own: all shelves of one side line up when imported together.

Geometry
  - Console side of each shelf = scanned stock inner surface + original hooks.
  - Back of each shelf = one flat glue face. It stands 0.8 mm proud of the glue plane,
    so it sits in the plate's 0.8 mm alignment pocket.
  - right and right_low are separate so the plate seam can pass between them.

Print
  - Orientation: as installed (hook lips up), so layers run along each hook shaft.
    Use a brim on the tall ones.
  - ASA or ABS, the same as the plate, so it can be solvent-welded. Avoid PLA.
  - 4+ walls, and 100% infill within about 10 mm of each hook.

Assembly - no glue near the console
  1. Weld the plate tiles together.
  2. Dry-fit: click the shelves onto the console, lower the plate, and check that every
     shelf drops into its pocket.
  3. Take everything off the console.
  4. Glue the shelves into their pockets on a bench, away from the console.
